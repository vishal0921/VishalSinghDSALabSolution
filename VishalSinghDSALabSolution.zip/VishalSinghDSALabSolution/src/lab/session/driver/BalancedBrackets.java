package lab.session.driver;

import java.util.Stack;

public class BalancedBrackets {

	public static boolean isBalanced(String bracketsExpression) {
		Stack<Character> stack = new Stack<>();

		for (int i = 0; i < bracketsExpression.length(); i++) {
			char ch = bracketsExpression.charAt(i);
			if (ch == '(' || ch == '[' || ch == '{') {
				stack.push(ch);
				continue;
			}

			if (stack.isEmpty()) {
				return false;
			}
			char c;
			switch (ch) {
			case '}':
				c = stack.pop();
				if (c == '(' || c == '[')
					return false;
				break;
			case ']':
				c = stack.pop();
				if (c == '(' || c == '{')
					return false;
				break;
			case ')':
				c = stack.pop();
				if (c == '{' || c == '[')
					return false;
				break;

			}
		}
		return stack.isEmpty();
	}

	public static void main(String args[]) {
		String bracketsExpression = "[{()}])";

		if (isBalanced(bracketsExpression)) {
			System.out.println("Balanced");
		} else {
			System.out.println("UnBalanced");
		}
	}

}
